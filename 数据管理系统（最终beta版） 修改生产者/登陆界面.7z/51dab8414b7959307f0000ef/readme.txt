下吧（http://xiaba.shijue.me/）是基于视觉中国（www.shijue.me）平台于2009年重磅推出的产品。

下吧以为设计师提供实用的专业服务为宗旨，通过提供全面的精品素材下载和用户的素材分享，为设计师以及设计
爱好者提供最实用、最贴心的设计素材，同时也将打造业界最具人性化的素材互动分享平台。


在下吧，你能第一时间下载到我们为你速递的国内外优质素材，还可以上传你的独家珍藏，和设计友朋们分享、互动、脑力激荡，我们悉力打造一个资源丰厚、服务周密、需取自由的平台，让你予取予求，随心所欲。

爱设计，做设计，来“下吧”，来下吧！

视觉中国下吧 http://xiaba.shijue.me/


为得到最佳的使用体验,建议您使用火狐(Firefox),谷歌Chrome,Safari这些现代的浏览器,

IE用户: 目前下吧只支持IE8。 对于IE6/IE7以及使用这些版本内核的浏览器, 一些功能将无法正常使用.

遨游用户: 建议升级到最新的双核3.0版本并切换至Webkit内核.


常见文件格式的打开方式 ：

*.ai ，eps格式：用illustrator 打开

*.PSD，PNG格式：用photoshop打开
(为节约资源，有部分PSD文件已关闭全部图层，下载后请使用Photoshop打开图层眼睛即可!)

*pdf格式文件请使用adobe reader软件打开!

*.cdr格式：用coreldraw 

*.ceb格式： 用方正公司Apabi Reader 

*.GB 格式：用ReadBook或电子小说阅读器 

*.gdb格式： 用Interbase Database 

*.html，htm，asp mht，asp，php 格式：用ie 

*.jpg，bmp，gif，tif，wmf 格式：用ACDsee 

*.ppt，wpt，pps 格式：用powerpoint
